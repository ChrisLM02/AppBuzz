package ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.appbuzz.R
import com.example.appbuzz.ui.theme.AppBuzzTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppBuzzTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {

                }
            }
        }
    }
}


@Preview(showBackground = true, showSystemUi = true)
@Composable
fun MainScreen() {
    Column(
        verticalArrangement = Arrangement.SpaceEvenly, modifier = Modifier
            .fillMaxSize()
            .background(Color.LightGray)
    ) {

        /*TODO =
        *  -> Seleccionar pregunta segun clase "Pregunta"
        *  [!] El texto actual es temporal, solo para ordenar los elementos
        * */

        Text(
            text = "AQUI VAN LAS PREGUNTAS",
            modifier = Modifier.fillMaxWidth(),
            fontSize = 25.sp,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.SemiBold
        )

        /*TODO =
        *  -> Seleccionar imagen segun clase "Pregunta"
        *  -> Cambiar en conjunto a la pregunta
        *  [!] La imagen actual es temporal, solo para ordenar los elementos
        * */

        Image(
            painter = painterResource(id = R.drawable.cdt_escudo),
            contentDescription = "Escudo Tenerife",
            Modifier
                .fillMaxWidth()
                .align(CenterHorizontally)
                .size(250.dp)
        )

        /*TODO =
        *  -> Seleccionar el texto segun la respuesta del usuario y la respuesta real
        *  -> El texto aparecera invisible hasta que se seleccione una de las dos respuestas
        *  -> Cambiar color del texto segun resultado
        *  [!] El texto actual es temporal, solo para ordenar los elementos
        * */

        Text(
            text = "Texto de acierto o fallo",
            modifier = Modifier.fillMaxWidth(),
            fontSize = 23.sp,
            textAlign = TextAlign.Center,
            fontWeight = FontWeight.SemiBold
        )

        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { /*TODO -> Comprobar si es verdadero
                                      -> Cambiar color segun resultado */
            }) {
                Text(text = "True", fontSize = 16.sp)
            }
            Button(onClick = { /*TODO -> Comprobar si es falso
                                      -> Cambiar color segun resultado */
            }) {
                Text(text = "False", fontSize = 16.sp)
            }
        }

        Button(
            onClick = { /*TODO -> Pasar a la siguiente pregunta*/ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "SIGUIENTE")
        }
    }
}