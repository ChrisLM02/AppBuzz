package data

import android.media.Image

data class Pregunta(var pregunta : String, var resultado : Boolean, var imagen : Image?)
