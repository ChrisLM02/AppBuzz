package data

import android.os.Bundle

class GeneradorPreguntas {

    var listaPreguntas : ArrayList<Pregunta> = ArrayList()

    fun onCreate(savedInstanceState: Bundle?) {
        var p1 : Pregunta = Pregunta("PREGUNTA 1", true, null)
        var p2 : Pregunta = Pregunta("PREGUNTA 1", true, null)
        var p3 : Pregunta = Pregunta("PREGUNTA 1", true, null)
        var p4 : Pregunta = Pregunta("PREGUNTA 1", true, null)
        var p5 : Pregunta = Pregunta("PREGUNTA 1", true, null)

        listaPreguntas.add(p1)
        listaPreguntas.add(p2)
        listaPreguntas.add(p3)
        listaPreguntas.add(p4)
        listaPreguntas.add(p5)
    }
}